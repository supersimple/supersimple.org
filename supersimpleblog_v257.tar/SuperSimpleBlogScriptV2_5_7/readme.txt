READ ME////////////////////////////////////

Thanks for downloading this Super Simple Blog Script.

This script is open source, feel free to use, share and modify it as you wish.
Please leave the credit in the blog page though. Fair is fair.

*****************

Setup Procedure:

1. set the strings in "sqlStrings.php". You will need to have a database set up on your server. You host can help you with this.

2. upload the files to your server. 

3. run the setup.php file

4. modify the CSS to meet your tastes.

****************

Please email any feedback to info@supersimple.org


****************

Updates in this version:

v2.5.3
- modified sql query in index.php to fix bug with posts not sorting correctly 
	by date