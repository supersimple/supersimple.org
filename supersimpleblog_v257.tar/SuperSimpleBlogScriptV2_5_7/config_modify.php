<?php
/*************************************

This file stores the constants used
in the CMS

*************************************/


$baseURL = '$baseURL';
$pageTitle = '$pageTitle';
$perPage = '$perPage';
$blogPageName = '$blogPageName';
$USERS = '$USERS';
$multiUsers = '$MULTIUSERS';
$imagesPerEntry = '$imagesPerEntry';
$COMMENTS = '$COMMENTS';
$TABLENAME = '$TABLENAME';
$TIMEOFFSET = '$TIMEOFFSET';

//RSS Settings

$websiteRoot = '$websiteRoot';
$rssFileName = '$rssFileName';
$rssLink = '$rssLink';
$rssDesc = '$rssDesc';

//CMS Settings

$users_login = '$users_login';
$show_global_nav = '$show_global_nav';
$global_nav_items = '$global_nav_items';

?>