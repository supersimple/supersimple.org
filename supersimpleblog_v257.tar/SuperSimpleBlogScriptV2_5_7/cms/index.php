<?
/***************************************************

index.php

This file returns allows user to navigate to the
page that they are looking for.

***************************************************/

require_once('../settings.php'); //include global prefs
require_once('includes/header.php'); // include global header
require_once('includes/footer.php');
?>
